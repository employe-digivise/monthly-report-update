# Directive: Generate PDF Report (The Iron Frame)

## Goal
Generate a premium, agency-grade A4 PDF report from structured JSON data while maintaining strict layout locking ("The Iron Frame").

## Architecture
- **Layer 1 (Directive)**: This document.
- **Layer 2 (Orchestration)**: AI Agent / Express Server.
- **Layer 3 (Execution)**: `execution/generator.js` (Node.js/Puppeteer).

## Input Specification
- **brandName**: String (e.g., "ATRIA PREMIUM")
- **reportMonth**: String (e.g., "January 2026")
- **enabledChannels**: Object (e.g., `{ "Shopee": true }`)
- **metrics**: Object (Summary and channel-specific metrics)
- **topProducts**: Array of objects (Product details, capped at 5 items in Execution Layer)

## Tools & Scripts
- **Tool**: `execution/generator.js`
- **Logic**: 
    - Data Slicing: Forces array limits (Top Products: 5, Performance: 7).
    - Image Processing: Converts local assets to Base64.
    - PDF Rendering: USes Puppeteer with A4 format and 0mm margins.

## Outputs
- **Deliverable**: `.pdf` file in `output/` directory (root).

## Edge Cases & Fail-safes
- **Empty Data**: Uses EJS conditionals to prevent empty layout blocks.
- **Long Text**: CSS `text-overflow: ellipsis` handles overflow in tables.
- **Large Payloads**: Server handles up to 50MB.

## Self-Annealing Notes
- If PDF generation fails, check `execution/assets/` for missing logos.
- If layout breaks, verify `.page` dimensions in `execution/templates/styles_atria.css`.
