# API Documentation for PDF Report Generator

## Endpoint
**URL**: `https://crazy-adults-flash.loca.lt/generate-report`
**Method**: `POST`
**Headers**: 
- `Content-Type: application/json`
- `Bypass-Tunnel-Reminder: true` (Optional, helps bypass localtunnel warning page if encountered)

## Request Body Structure (JSON)

```json
{
  "brandName": "ATRIA PREMIUM",
  "reportMonth": "JANUARY",
  "reportYear": "2026",
  "showLogo": true,
  "logoUrl": "", 
  "footerText": "CONFIDENTIAL - DIGIVISE REPORT 2026",
  "enabledChannels": {
    "shopee": true,
    "tiktok": false,
    "tokopedia": false,
    "lazada": false,
    "blibli": false,
    "cpas": true
  },
  "metrics": {
    "unfulfilledOrders": 0.5,
    "lateShipment": 0.8,
    "chatResponseRate": 98.5,
    "overallRating": 4.8,
    "summary": "Performa toko bulan ini menunjukkan peningkatan signifikan."
  },
  "promotionTools": {
    "paketDiskon": true,
    "gratisOngkirXTRA": true,
    "voucherIkutiToko": true
  },
  "globalRevenue": {
    "totalRevenue": 850000000,
    "totalOrders": 5667,
    "chartData": {
      "month": "JANUARY",
      "labels": ["Week 1", "Week 2", "Week 3", "Week 4"],
      "revenueData": [180000000, 220000000, 195000000, 255000000],
      "ordersData": [1200, 1467, 1300, 1700]
    },
    "summary": "Revenue meningkat 15% dibanding bulan lalu."
  },
  "globalPerformanceDetail": {
    "comparisonData": [],
    "aiConclusion": ["Poin 1", "Poin 2"]
  },
  "storePerformance": {
    "adSales": 94.18,
    "existingSales": 5.82,
    "totalRevenue": 261488920,
    "notes": "Kontribusi iklan dominan."
  },
  "shopeeAdsMetrics": {
    "dilihat": 2845336,
    "ctr": "4.82%",
    "klik": 137233,
    "cpc": "Rp 186",
    "penjualan": "Rp 246M",
    "biaya": "Rp 25M"
  },
  "topProducts": [
    {
      "name": "Produk A",
      "image": "https://example.com/image.jpg",
      "soldPercent": "4.05%",
      "qty": 2623,
      "revenue": 33608225
    }
  ],
  "cpas_data": {
    "period": ["Dec 2025", "Jan 2026"],
    "awareness_nv": [],
    "conversion_rm": [],
    "best_campaigns": {
      "nv": { "name": "Campaign NV", "image_url": "https://example.com/nv.jpg" },
      "rm": { "name": "Campaign RM", "image_url": "https://example.com/rm.jpg" }
    }
  },
  "actionPlan": []
}
```

## Notes
- Ensure image URLs are accessible or provide Base64 strings.
- The server will process the request and return a JSON response with the download URL.
