const puppeteer = require('puppeteer');
const ejs = require('ejs');
const fs = require('fs-extra');
const path = require('path');

/**
 * Convert local image to Base64
 * @param {string} filePath 
 * @returns {string} base64 string
 */
async function imageToBase64(filePath) {
    try {
        if (!fs.existsSync(filePath)) {
            console.warn(`File not found: ${filePath}`);
            return '';
        }
        const bitmap = await fs.readFile(filePath);
        const extension = path.extname(filePath).replace('.', '');
        return `data:image/${extension};base64,${bitmap.toString('base64')}`;
    } catch (error) {
        console.error(`Error converting image ${filePath}:`, error);
        return '';
    }
}

async function generatePDF(data) {
    try {
        console.log('Starting PDF generation...');

        // 1. DATA SLICING & TRUNCATION (THE IRON FRAME LOGIC)
        const truncateString = (str, limit = 50) => {
            if (!str) return '';
            return str.length > limit ? str.substring(0, limit) + '...' : str;
        };

        // Table Lock: Ensure array and limit product data to 5 items
        if (!data.topProducts || !Array.isArray(data.topProducts)) {
            data.topProducts = [];
        }

        // Slice to 5
        data.topProducts = data.topProducts.slice(0, 5).map(p => ({
            ...p,
            name: truncateString(p.name)
        }));

        // Action Plan: Limit to 5 rows and truncate text
        if (data.actionPlan && Array.isArray(data.actionPlan)) {
            data.actionPlan = data.actionPlan.slice(0, 5).map(ap => ({
                ...ap,
                problem: truncateString(ap.problem),
                solution: truncateString(ap.solution),
                pic: truncateString(ap.pic, 20)
            }));
        }

        // 2. IMAGE CONVERSION (Base64)
        // Processing logo
        if (!data.logoUrl) {
            const logoPath = path.join(__dirname, 'assets', 'logo.png');
            if (!fs.existsSync(path.join(__dirname, 'assets'))) {
                await fs.ensureDir(path.join(__dirname, 'assets'));
                const dummyLogo = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg==', 'base64');
                await fs.writeFile(logoPath, dummyLogo);
            }
            data.logoUrl = await imageToBase64(logoPath);
        } else if (data.logoUrl && !data.logoUrl.startsWith('http') && !data.logoUrl.startsWith('data:')) {
            data.logoUrl = await imageToBase64(data.logoUrl);
        }

        // Process Top Products Images
        if (data.topProducts && Array.isArray(data.topProducts)) {
            for (const p of data.topProducts) {
                if (p.image && !p.image.startsWith('http') && !p.image.startsWith('data:')) {
                    p.image = await imageToBase64(p.image);
                }
            }
        }

        // Process CPAS Best Campaign Images
        if (data.cpas_data && data.cpas_data.best_campaigns) {
            const types = ['nv', 'rm'];
            for (const type of types) {
                if (data.cpas_data.best_campaigns[type] && data.cpas_data.best_campaigns[type].image_url) {
                    let imgUrl = data.cpas_data.best_campaigns[type].image_url;
                    if (imgUrl && !imgUrl.startsWith('http') && !imgUrl.startsWith('data:')) {
                        data.cpas_data.best_campaigns[type].image_url = await imageToBase64(imgUrl);
                    }
                }
            }
        }

        // 3. READ CSS AND EJS
        const cssContent = await fs.readFile(path.join(__dirname, 'templates', 'styles_atria.css'), 'utf-8');
        const templatePath = path.join(__dirname, 'templates', 'template_atria.ejs');
        const templateContent = await fs.readFile(templatePath, 'utf-8');

        // 4. RENDER HTML
        const html = ejs.render(templateContent, {
            ...data,
            cssContent: cssContent
        });

        // 5. PUPPETEER RENDER
        const browser = await puppeteer.launch({
            headless: 'new',
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        });
        const page = await browser.newPage();

        await page.setContent(html, { waitUntil: 'networkidle0' });

        const outputDir = path.join(__dirname, '..', 'output');
        const outputPath = path.join(outputDir, `Report_${data.brandName.replace(/\s+/g, '_')}_${Date.now()}.pdf`);
        await fs.ensureDir(outputDir);

        await page.pdf({
            path: outputPath,
            format: 'A4',
            printBackground: true,
            margin: {
                top: '0mm',
                right: '0mm',
                bottom: '0mm',
                left: '0mm'
            }
        });

        await browser.close();
        console.log(`PDF Generated Successfully: ${outputPath}`);
        return outputPath;

    } catch (error) {
        console.error('Error in PDF generation:', error);
        throw error;
    }
}

// SAMPLE EXECUTION WITH ELVICTO DATA
const elvictoSample = {
    "brandName": "ELVICTO",
    "reportMonth": "JANUARY",
    "reportYear": "2026",
    "showLogo": true,
    "logoUrl": "", // Will fallback to dummy in generator
    "footerText": "CONFIDENTIAL - DIGIVISE REPORT 2026",
    "enabledChannels": {
        "shopee": true,
        "tiktok": false,
        "tokopedia": false,
        "lazada": false,
        "blibli": false,
        "cpas": true
    },
    "metrics": {
        "unfulfilledOrders": 0.5,
        "lateShipment": 0.8,
        "chatResponseRate": 98.5,
        "overallRating": 4.8,
        "summary": "Performa toko bulan ini menunjukkan peningkatan signifikan dengan tingkat kepuasan pelanggan yang baik."
    },
    "promotionTools": {
        "paketDiskon": true,
        "gratisOngkirXTRA": true,
        "voucherIkutiToko": true,
        "voucherTokoSaya": true,
        "flashSaleTokoSaya": false,
        "komboHemat": true,
        "chatBroadcast": true,
        "shopeeLive": false
    },
    "globalRevenue": {
        "totalRevenue": 850000000,
        "totalOrders": 5667,
        "chartData": {
            "month": "JANUARY",
            "labels": ["Week 1", "Week 2", "Week 3", "Week 4"],
            "revenueData": [180000000, 220000000, 195000000, 255000000],
            "ordersData": [1200, 1467, 1300, 1700]
        },
        "summary": "Revenue mengalami peningkatan 15% dibanding bulan lalu dengan kontribusi terbesar dari promosi payday."
    },
    "globalPerformanceDetail": {
        "comparisonData": [
            {
                "metric": "Revenue",
                "channels": { "shopee": "Rp 650M" },
                "thisMonth": "Rp 850M",
                "lastMonth": "Rp 739M",
                "growth": "+15.0%"
            },
            {
                "metric": "Cost Spend",
                "channels": { "shopee": "Rp 45M" },
                "thisMonth": "Rp 68M",
                "lastMonth": "Rp 59M",
                "growth": "+15.3%"
            },
            {
                "metric": "CIR",
                "channels": {},
                "thisMonth": "8.0%",
                "lastMonth": "8.0%",
                "growth": "0.0%"
            },
            {
                "metric": "ROAS",
                "channels": {},
                "thisMonth": "12.50x",
                "lastMonth": "12.53x",
                "growth": "-0.2%"
            }
        ],
        "aiConclusion": [
            "Tingkatkan budget iklan pada minggu ke-4 karena terbukti menghasilkan revenue tertinggi.",
            "Fokus pada produk best seller untuk memaksimalkan ROAS."
        ]
    },
    "storePerformance": {
        "adSales": 94.18,
        "existingSales": 5.82,
        "totalRevenue": 261488920,
        "notes": "Dapat dilihat bahwa kontribusi omset terbanyak datang dari penjualan iklan, mencapai 94.18% dari total kontribusi omset."
    },
    "shopeeAdsMetrics": {
        "dilihat": 2845336,
        "ctr": "4.82%",
        "klik": 137233,
        "cpc": "Rp 186",
        "penjualan": "Rp 246,274,889",
        "biaya": "Rp 25,516,404"
    },
    "topProducts": [
        {
            "name": "KAUFAZ JUMBO Growing Magic Animal Water/ Mainan Hewan Rendam Air Tumbuh Besar / Mainan Edukasi Anak",
            "image": "https://images.tokopedia.net/img/cache/700/Vqb7pG/2021/11/4/2e08e8cb-7e50-4d43-9878-c068301548a3.jpg",
            "soldPercent": "4.05%",
            "qty": 2623,
            "revenue": 33608225
        },
        {
            "name": "KAUFAZ 30pc (1 pack) Puzzle 3D Motif Hewan laut Dino Animal Serangga Pesawat Kendaraan Transportasi | Mainan Edukasi DIY",
            "image": "https://images.tokopedia.net/img/cache/700/Vqb7pG/2021/11/4/2e08e8cb-7e50-4d43-9878-c068301548a3.jpg",
            "soldPercent": "2.91%",
            "qty": 1884,
            "revenue": 22475689
        },
        {
            "name": "KAUFAZ Masking Tape Warna Warni / Isolasi Kertas / Selotip Kertas Warna Warni",
            "image": "https://images.tokopedia.net/img/cache/700/Vqb7pG/2021/11/4/2e08e8cb-7e50-4d43-9878-c068301548a3.jpg",
            "soldPercent": "1.92%",
            "qty": 1242,
            "revenue": 9467023
        }
    ],
    "cpas_data": {
        "period": ["December 2025", "January 2026"],
        "awareness_nv": [
            { "metric": "Ads Spend", "prev": "Rp5,314,930", "current": "Rp777,861", "growth": "-85.36%" },
            { "metric": "Impression", "prev": "715,409", "current": "183,862", "growth": "-74.30%" },
            { "metric": "Link Clicks", "prev": "16,979", "current": "2,220", "growth": "-86.93%" },
            { "metric": "CTR (%)", "prev": "2.37%", "current": "1.21%", "growth": "-48.95%" },
            { "metric": "CPC (Rp)", "prev": "Rp313", "current": "Rp350", "growth": "11.82%" }
        ],
        "conversion_rm": [
            { "metric": "Ads Spend", "prev": "Rp2,027,615", "current": "Rp635,052", "growth": "-68.68%" },
            { "metric": "Frequency", "prev": "14.20", "current": "8.69", "growth": "-38.80%" },
            { "metric": "Revenue", "prev": "Rp2,571,936", "current": "Rp647,738", "growth": "-74.82%" },
            { "metric": "Transaction", "prev": "216", "current": "59", "growth": "-72.69%" },
            { "metric": "ROAS", "prev": "1.27", "current": "1.02", "growth": "-19.69%" }
        ],
        "best_campaigns": {
            "nv": {
                "name": "NV | Purchase",
                "impression": "53,034",
                "ctr": "1.08%",
                "spend": "Rp330,082",
                "atc": "279",
                "c_atc": "Rp1,183",
                "image_url": "https://example.com/nv-campaign.jpg"
            },
            "rm": {
                "name": "RM | ALL Product | CBO",
                "frequency": "6.75",
                "spend": "Rp481,197",
                "revenue": "Rp482,059",
                "qty": "43",
                "roas": "1",
                "image_url": "https://example.com/rm-campaign.jpg"
            }
        }
    },
    "actionPlan": [
        {
            "priority": "High",
            "problem": "Stock produk best seller menipis",
            "solution": "Koordinasi dengan tim warehouse untuk restock ASAP",
            "pic": "Tim Operations",
            "deadline": "2026-02-10"
        },
        {
            "priority": "Medium",
            "problem": "CTR iklan menurun 5% dari bulan lalu",
            "solution": "A/B testing creative baru dengan hook yang lebih menarik",
            "pic": "Tim Digital Marketing",
            "deadline": "2026-02-15"
        },
        {
            "priority": "Low",
            "problem": "Response rate chat belum 100%",
            "solution": "Training CS untuk meningkatkan kecepatan respons",
            "pic": "Tim CS",
            "deadline": "2026-02-20"
        }
    ]
};

if (require.main === module) {
    generatePDF(elvictoSample);
}

module.exports = { generatePDF };
