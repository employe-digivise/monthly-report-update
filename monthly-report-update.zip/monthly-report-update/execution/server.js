const express = require('express');
const bodyParser = require('body-parser');
const morgan = require('morgan');
const path = require('path');
const { generatePDF } = require('./generator');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(morgan('dev'));
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));

// Serve static output files from root output folder
app.use('/output', express.static(path.join(__dirname, '..', 'output')));

/**
 * Compatible endpoint with monthly-report-generator-main 2
 */
app.post('/generate-report', async (req, res) => {
    try {
        const data = req.body;

        if (!data || !data.brandName) {
            return res.status(400).json({
                success: false,
                message: 'Invalid data format. brandName is required.'
            });
        }

        console.log(`Received request for brand: ${data.brandName}`);

        // Trigger the Iron Frame generator
        const pdfPath = await generatePDF(data);
        const fileName = path.basename(pdfPath);

        res.status(200).json({
            success: true,
            message: 'PDF generated successfully',
            fileName: fileName,
            downloadUrl: `${req.protocol}://${req.get('host')}/output/${fileName}`,
            path: pdfPath
        });

    } catch (error) {
        console.error('Server error during PDF generation:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: error.message
        });
    }
});

app.get('/', (req, res) => {
    res.send('PDF Report Generator Server (The Iron Frame) is running.');
});

app.listen(PORT, () => {
    console.log(`-----------------------------------------------`);
    console.log(`Server is running on http://localhost:${PORT}`);
    console.log(`Endpoint: POST http://localhost:${PORT}/generate-report`);
    console.log(`To expose via Ngrok: ngrok http ${PORT}`);
    console.log(`-----------------------------------------------`);
});
